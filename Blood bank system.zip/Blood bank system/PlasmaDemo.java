package dbms_plasma;
import javax.swing.JFrame;


public final class PlasmaDemo {

	public static void main(String[] args)  {
		
		Login plasma = new Login();
		plasma.setSize(5000,1500);
		plasma.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		plasma.setVisible(true);


	}

}



